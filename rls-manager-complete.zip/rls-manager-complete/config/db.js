// config/db.js — Oracle DB Connection Pool
require('dotenv').config();
const oracledb = require('oracledb');

let pool;

async function initialize() {
  try {
    oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;
    oracledb.autoCommit = true;

    pool = await oracledb.createPool({
      user:             process.env.DB_USER,
      password:         process.env.DB_PASSWORD,
      connectString:    `${process.env.DB_HOST}:${process.env.DB_PORT}/${process.env.DB_SERVICE}`,
      poolMin:          2,
      poolMax:          10,
      poolIncrement:    1,
      poolTimeout:      60,
      stmtCacheSize:    30
    });

    console.log('✅ Oracle DB Pool initialized');
    return pool;
  } catch (err) {
    console.error('❌ Oracle DB Pool failed:', err.message);
    throw err;
  }
}

async function getConnection() {
  if (!pool) throw new Error('DB pool not initialized');
  return pool.getConnection();
}

async function execute(sql, params = [], options = {}) {
  let conn;
  try {
    conn = await getConnection();
    const result = await conn.execute(sql, params, {
      outFormat: oracledb.OUT_FORMAT_OBJECT,
      ...options
    });
    return result;
  } finally {
    if (conn) await conn.close();
  }
}

async function close() {
  if (pool) await pool.close(10);
}

module.exports = { initialize, getConnection, execute, close };
