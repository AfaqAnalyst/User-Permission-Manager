// config/setup.js — One-time Oracle DB Setup
const db = require('./db');

const SETUP_STATEMENTS = [

  // ── Organizations Table ──────────────────────────────
  `BEGIN
    EXECUTE IMMEDIATE '
      CREATE TABLE rls_organizations (
        org_id    VARCHAR2(20)  PRIMARY KEY,
        org_name  VARCHAR2(200) NOT NULL,
        is_active NUMBER(1)     DEFAULT 1,
        created_at DATE         DEFAULT SYSDATE
      )
    ';
  EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -955 THEN RAISE; END IF;
  END;`,

  // ── KPI Master Table ─────────────────────────────────
  `BEGIN
    EXECUTE IMMEDIATE '
      CREATE TABLE rls_kpi_master (
        kpi_code  VARCHAR2(20)  PRIMARY KEY,
        kpi_name  VARCHAR2(300) NOT NULL,
        kpi_order NUMBER(3)     DEFAULT 99,
        is_active NUMBER(1)     DEFAULT 1
      )
    ';
  EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -955 THEN RAISE; END IF;
  END;`,

  // ── Users Table ──────────────────────────────────────
  `BEGIN
    EXECUTE IMMEDIATE '
      CREATE TABLE rls_users (
        id         NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
        username   VARCHAR2(150) NOT NULL UNIQUE,
        full_name  VARCHAR2(200),
        department VARCHAR2(100),
        role_label VARCHAR2(100),
        is_active  NUMBER(1)    DEFAULT 1,
        created_at DATE         DEFAULT SYSDATE,
        updated_at DATE         DEFAULT SYSDATE
      )
    ';
  EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -955 THEN RAISE; END IF;
  END;`,

  // ── Permissions Table ────────────────────────────────
  `BEGIN
    EXECUTE IMMEDIATE '
      CREATE TABLE rls_permissions (
        id         NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
        user_id    NUMBER        NOT NULL REFERENCES rls_users(id) ON DELETE CASCADE,
        kpi_code   VARCHAR2(20)  NOT NULL,
        org_id     VARCHAR2(20)  NOT NULL,
        created_at DATE          DEFAULT SYSDATE,
        CONSTRAINT uq_perm UNIQUE (user_id, kpi_code, org_id)
      )
    ';
  EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -955 THEN RAISE; END IF;
  END;`,

  // ── Audit Log Table ──────────────────────────────────
  `BEGIN
    EXECUTE IMMEDIATE '
      CREATE TABLE rls_audit_log (
        id          NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
        action      VARCHAR2(50)  NOT NULL,
        target_user VARCHAR2(150),
        changed_by  VARCHAR2(150),
        detail      VARCHAR2(4000),
        created_at  DATE DEFAULT SYSDATE
      )
    ';
  EXCEPTION WHEN OTHERS THEN
    IF SQLCODE != -955 THEN RAISE; END IF;
  END;`,

  // ── Seed Organizations ───────────────────────────────
  `BEGIN
    MERGE INTO rls_organizations t USING (
      SELECT '81'   org_id, 'Interloop Hosiery'     org_name FROM DUAL UNION ALL
      SELECT '83',          'Interloop Spinning'             FROM DUAL UNION ALL
      SELECT '84',          'Interloop Yarn Dyeing'          FROM DUAL UNION ALL
      SELECT '2021',        'Interloop Limited'              FROM DUAL UNION ALL
      SELECT '2670',        'Interloop Denim'                FROM DUAL UNION ALL
      SELECT '2782',        'Interloop Active Wear'          FROM DUAL UNION ALL
      SELECT '4616',        'Interloop Apparel'              FROM DUAL
    ) s ON (t.org_id = s.org_id)
    WHEN NOT MATCHED THEN INSERT (org_id, org_name) VALUES (s.org_id, s.org_name);
  END;`,

  // ── Seed KPIs ────────────────────────────────────────
  `BEGIN
    MERGE INTO rls_kpi_master t USING (
      SELECT 'TS'  kpi_code, 'Total Sales'                                    kpi_name, 1  kpi_order FROM DUAL UNION ALL
      SELECT 'CB',           'Cost Breakdown',                                           2            FROM DUAL UNION ALL
      SELECT 'SCM',          'Sales Contribution Margin',                                3            FROM DUAL UNION ALL
      SELECT 'CTA',          'Cost Trend Analysis',                                      4            FROM DUAL UNION ALL
      SELECT 'TID',          'Total Inventory Days',                                     5            FROM DUAL UNION ALL
      SELECT 'OEE',          'OEE (Overall Equipment Efficiency)',                       6            FROM DUAL UNION ALL
      SELECT 'QI',           'Quality Index',                                            7            FROM DUAL UNION ALL
      SELECT 'YLD',          'Yield',                                                    8            FROM DUAL UNION ALL
      SELECT 'TFS',          'Transfer to FGS & Shipment to Quantity',                  9            FROM DUAL UNION ALL
      SELECT 'CCT',          'Conversion Cost Trend',                                   10            FROM DUAL UNION ALL
      SELECT 'CC',           'Critical Complaints',                                     11            FROM DUAL UNION ALL
      SELECT 'OTP',          'OTP (One Time Performance)',                              12            FROM DUAL UNION ALL
      SELECT 'ABF',          'Actual vs BPW Budget vs Forecast (DZNS)',                13            FROM DUAL UNION ALL
      SELECT 'HRC',          'Total HR Cost as % of Sales',                            14            FROM DUAL UNION ALL
      SELECT 'ESR',          'Executive Strength Ratio & Diversity %age',              15            FROM DUAL UNION ALL
      SELECT 'ETR',          'Employee Turnover Rate',                                  16            FROM DUAL
    ) s ON (t.kpi_code = s.kpi_code)
    WHEN NOT MATCHED THEN INSERT (kpi_code, kpi_name, kpi_order) VALUES (s.kpi_code, s.kpi_name, s.kpi_order);
  END;`,

  // ── Tableau RLS View ─────────────────────────────────
  `CREATE OR REPLACE VIEW v_rls_permissions AS
   SELECT DISTINCT
       u.username,
       CASE WHEN p.kpi_code = 'ALL' THEN k.kpi_code ELSE p.kpi_code END AS kpi_code,
       CASE WHEN p.org_id   = 'ALL' THEN o.org_id   ELSE p.org_id   END AS org_id
   FROM rls_permissions p
   JOIN rls_users       u ON u.id = p.user_id AND u.is_active = 1
   CROSS JOIN rls_kpi_master   k
   CROSS JOIN rls_organizations o
   WHERE
       (p.kpi_code = 'ALL' OR p.kpi_code = k.kpi_code)
   AND (p.org_id   = 'ALL' OR p.org_id   = o.org_id)
   AND k.is_active = 1
   AND o.is_active = 1`
];

async function runSetup() {
  const results = { success: [], failed: [] };

  for (let i = 0; i < SETUP_STATEMENTS.length; i++) {
    try {
      await db.execute(SETUP_STATEMENTS[i]);
      results.success.push(`Statement ${i + 1} executed`);
    } catch (err) {
      results.failed.push({ statement: i + 1, error: err.message });
    }
  }
  return results;
}

module.exports = { runSetup };
