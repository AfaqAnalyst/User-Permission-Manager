// routes/meta.js — KPIs, Orgs, Dashboard stats
const express = require('express');
const router  = express.Router();
const db      = require('../config/db');
const setup   = require('../config/setup');

// ── GET KPI list ──────────────────────────────────────
router.get('/kpis', async (req, res) => {
  try {
    const result = await db.execute(
      `SELECT kpi_code, kpi_name, kpi_order, is_active
       FROM rls_kpi_master
       WHERE is_active = 1
       ORDER BY kpi_order`
    );
    res.json({ success: true, data: result.rows.map(r => ({
      code: r.KPI_CODE, name: r.KPI_NAME, order: r.KPI_ORDER
    }))});
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── GET Organization list ─────────────────────────────
router.get('/orgs', async (req, res) => {
  try {
    const result = await db.execute(
      `SELECT org_id, org_name, is_active
       FROM rls_organizations
       WHERE is_active = 1
       ORDER BY TO_NUMBER(org_id)`
    );
    res.json({ success: true, data: result.rows.map(r => ({
      id: r.ORG_ID, name: r.ORG_NAME
    }))});
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── GET Dashboard stats ───────────────────────────────
router.get('/dashboard', async (req, res) => {
  try {
    const [totalUsers, activeUsers, fullAccess, auditRecent] = await Promise.all([
      db.execute(`SELECT COUNT(*) AS cnt FROM rls_users`),
      db.execute(`SELECT COUNT(*) AS cnt FROM rls_users WHERE is_active = 1`),
      db.execute(`
        SELECT COUNT(DISTINCT user_id) AS cnt FROM rls_users u
        WHERE EXISTS (
          SELECT 1 FROM rls_permissions p
          WHERE p.user_id = u.id AND p.kpi_code = 'ALL' AND p.org_id = 'ALL'
        )`),
      db.execute(`
        SELECT action, target_user, TO_CHAR(created_at,'DD-Mon HH24:MI') AS ts
        FROM rls_audit_log
        ORDER BY created_at DESC
        FETCH FIRST 5 ROWS ONLY
      `)
    ]);

    // Per-org user count
    const orgStats = await db.execute(`
      SELECT o.org_name, COUNT(DISTINCT p.user_id) AS user_count
      FROM rls_organizations o
      LEFT JOIN rls_permissions p ON p.org_id = o.org_id OR p.org_id = 'ALL'
      GROUP BY o.org_id, o.org_name
      ORDER BY TO_NUMBER(o.org_id)
    `);

    // Per-KPI user count
    const kpiStats = await db.execute(`
      SELECT k.kpi_name, COUNT(DISTINCT p.user_id) AS user_count
      FROM rls_kpi_master k
      LEFT JOIN rls_permissions p ON p.kpi_code = k.kpi_code OR p.kpi_code = 'ALL'
      GROUP BY k.kpi_code, k.kpi_name, k.kpi_order
      ORDER BY k.kpi_order
    `);

    res.json({
      success: true,
      data: {
        total_users:   totalUsers.rows[0].CNT,
        active_users:  activeUsers.rows[0].CNT,
        inactive_users: totalUsers.rows[0].CNT - activeUsers.rows[0].CNT,
        full_access:   fullAccess.rows[0].CNT,
        restricted:    activeUsers.rows[0].CNT - fullAccess.rows[0].CNT,
        recent_audit:  auditRecent.rows.map(r => ({ action: r.ACTION, user: r.TARGET_USER, ts: r.TS })),
        org_stats:     orgStats.rows.map(r => ({ name: r.ORG_NAME, count: r.USER_COUNT })),
        kpi_stats:     kpiStats.rows.map(r => ({ name: r.KPI_NAME, count: r.USER_COUNT }))
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── POST bulk import users (CSV-like array) ───────────
router.post('/bulk-import', async (req, res) => {
  const { users } = req.body;
  if (!Array.isArray(users)) return res.status(400).json({ success: false, error: 'users array required' });

  const results = { created: 0, skipped: 0, errors: [] };
  for (const u of users) {
    try {
      const dup = await db.execute(`SELECT id FROM rls_users WHERE LOWER(username) = LOWER(:u)`, [u.username]);
      if (dup.rows.length) { results.skipped++; continue; }

      const userResult = await db.execute(
        `INSERT INTO rls_users (username, full_name, department, role_label)
         VALUES (:u, :f, :d, :r) RETURNING id INTO :id`,
        { u: u.username.toLowerCase().trim(), f: u.full_name||null, d: u.department||null, r: u.role_label||null,
          id: { dir: require('oracledb').BIND_OUT, type: require('oracledb').NUMBER } }
      );
      const uid = userResult.outBinds.id[0];
      for (const kpi of u.kpis||[]) {
        for (const org of u.orgs||[]) {
          await db.execute(`INSERT INTO rls_permissions (user_id, kpi_code, org_id) VALUES (:u,:k,:o)`, [uid,kpi,org]);
        }
      }
      results.created++;
    } catch (e) {
      results.errors.push({ user: u.username, error: e.message });
    }
  }
  res.json({ success: true, data: results });
});

// ── POST run DB setup ─────────────────────────────────
router.post('/setup', async (req, res) => {
  try {
    const results = await setup.runSetup();
    res.json({ success: true, data: results });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── GET health check ──────────────────────────────────
router.get('/health', async (req, res) => {
  try {
    await db.execute('SELECT 1 FROM DUAL');
    res.json({ success: true, status: 'healthy', db: 'connected', time: new Date().toISOString() });
  } catch (err) {
    res.status(503).json({ success: false, status: 'unhealthy', error: err.message });
  }
});

module.exports = router;
