// routes/users.js
const express = require('express');
const router  = express.Router();
const db      = require('../config/db');

// ── GET all users with their permissions ──────────────
router.get('/', async (req, res) => {
  try {
    const users = await db.execute(`
      SELECT
        u.id, u.username, u.full_name, u.department,
        u.role_label, u.is_active,
        TO_CHAR(u.created_at,'YYYY-MM-DD HH24:MI') AS created_at,
        TO_CHAR(u.updated_at,'YYYY-MM-DD HH24:MI') AS updated_at
      FROM rls_users u
      ORDER BY u.full_name
    `);

    const perms = await db.execute(`
      SELECT p.user_id, p.kpi_code, p.org_id
      FROM rls_permissions p
      ORDER BY p.user_id
    `);

    // Attach permissions to each user
    const permMap = {};
    perms.rows.forEach(p => {
      if (!permMap[p.USER_ID]) permMap[p.USER_ID] = { kpis: [], orgs: [] };
      if (!permMap[p.USER_ID].kpis.includes(p.KPI_CODE)) permMap[p.USER_ID].kpis.push(p.KPI_CODE);
      if (!permMap[p.USER_ID].orgs.includes(p.ORG_ID))   permMap[p.USER_ID].orgs.push(p.ORG_ID);
    });

    const result = users.rows.map(u => ({
      id:         u.ID,
      username:   u.USERNAME,
      full_name:  u.FULL_NAME,
      department: u.DEPARTMENT,
      role_label: u.ROLE_LABEL,
      is_active:  u.IS_ACTIVE,
      created_at: u.CREATED_AT,
      updated_at: u.UPDATED_AT,
      kpis:       permMap[u.ID]?.kpis || [],
      orgs:       permMap[u.ID]?.orgs || []
    }));

    res.json({ success: true, data: result, total: result.length });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── GET single user ───────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const user = await db.execute(
      `SELECT u.*, TO_CHAR(u.created_at,'YYYY-MM-DD HH24:MI') AS created_fmt
       FROM rls_users u WHERE u.id = :id`,
      [req.params.id]
    );
    if (!user.rows.length) return res.status(404).json({ success: false, error: 'User not found' });

    const perms = await db.execute(
      `SELECT kpi_code, org_id FROM rls_permissions WHERE user_id = :id`,
      [req.params.id]
    );

    const u = user.rows[0];
    res.json({
      success: true,
      data: {
        id:         u.ID,
        username:   u.USERNAME,
        full_name:  u.FULL_NAME,
        department: u.DEPARTMENT,
        role_label: u.ROLE_LABEL,
        is_active:  u.IS_ACTIVE,
        kpis:       perms.rows.map(p => p.KPI_CODE),
        orgs:       perms.rows.map(p => p.ORG_ID)
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── POST create user ──────────────────────────────────
router.post('/', async (req, res) => {
  const { username, full_name, department, role_label, kpis, orgs } = req.body;

  if (!username || !kpis?.length || !orgs?.length) {
    return res.status(400).json({ success: false, error: 'username, kpis and orgs are required' });
  }

  let conn;
  try {
    conn = await db.getConnection();

    // Check duplicate
    const dup = await conn.execute(
      `SELECT id FROM rls_users WHERE LOWER(username) = LOWER(:u)`,
      [username]
    );
    if (dup.rows.length) {
      return res.status(409).json({ success: false, error: 'User with this email already exists' });
    }

    // Insert user
    const userResult = await conn.execute(
      `INSERT INTO rls_users (username, full_name, department, role_label)
       VALUES (:u, :f, :d, :r)
       RETURNING id INTO :id`,
      {
        u: username.toLowerCase().trim(),
        f: full_name || null,
        d: department || null,
        r: role_label || null,
        id: { dir: require('oracledb').BIND_OUT, type: require('oracledb').NUMBER }
      }
    );

    const userId = userResult.outBinds.id[0];

    // Insert permissions (deduplicated kpi/org combos)
    const kpiList = [...new Set(kpis)];
    const orgList = [...new Set(orgs)];

    for (const kpi of kpiList) {
      for (const org of orgList) {
        await conn.execute(
          `INSERT INTO rls_permissions (user_id, kpi_code, org_id) VALUES (:uid, :k, :o)`,
          [userId, kpi, org]
        );
      }
    }

    await conn.commit();

    // Audit log
    await conn.execute(
      `INSERT INTO rls_audit_log (action, target_user, changed_by, detail)
       VALUES ('CREATE_USER', :u, 'system', :d)`,
      [username, `KPIs: ${kpiList.join(',')} | ORGs: ${orgList.join(',')}`]
    );
    await conn.commit();

    res.status(201).json({ success: true, message: 'User created', data: { id: userId, username } });
  } catch (err) {
    if (conn) await conn.rollback();
    res.status(500).json({ success: false, error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

// ── PUT update user ───────────────────────────────────
router.put('/:id', async (req, res) => {
  const { username, full_name, department, role_label, is_active, kpis, orgs } = req.body;
  const userId = parseInt(req.params.id);

  let conn;
  try {
    conn = await db.getConnection();

    // Update user info
    await conn.execute(
      `UPDATE rls_users
       SET username   = :u,
           full_name  = :f,
           department = :d,
           role_label = :r,
           is_active  = :a,
           updated_at = SYSDATE
       WHERE id = :id`,
      {
        u: username?.toLowerCase().trim(),
        f: full_name || null,
        d: department || null,
        r: role_label || null,
        a: is_active ?? 1,
        id: userId
      }
    );

    // Replace permissions if provided
    if (kpis && orgs) {
      await conn.execute(`DELETE FROM rls_permissions WHERE user_id = :id`, [userId]);

      const kpiList = [...new Set(kpis)];
      const orgList = [...new Set(orgs)];

      for (const kpi of kpiList) {
        for (const org of orgList) {
          await conn.execute(
            `INSERT INTO rls_permissions (user_id, kpi_code, org_id) VALUES (:uid, :k, :o)`,
            [userId, kpi, org]
          );
        }
      }
    }

    await conn.commit();

    // Audit
    await conn.execute(
      `INSERT INTO rls_audit_log (action, target_user, changed_by, detail)
       VALUES ('UPDATE_USER', :u, 'system', :d)`,
      [username, `KPIs: ${(kpis||[]).join(',')} | ORGs: ${(orgs||[]).join(',')}`]
    );
    await conn.commit();

    res.json({ success: true, message: 'User updated' });
  } catch (err) {
    if (conn) await conn.rollback();
    res.status(500).json({ success: false, error: err.message });
  } finally {
    if (conn) await conn.close();
  }
});

// ── DELETE user ───────────────────────────────────────
router.delete('/:id', async (req, res) => {
  try {
    const user = await db.execute(`SELECT username FROM rls_users WHERE id = :id`, [req.params.id]);
    if (!user.rows.length) return res.status(404).json({ success: false, error: 'User not found' });

    // Permissions auto-deleted via ON DELETE CASCADE
    await db.execute(`DELETE FROM rls_users WHERE id = :id`, [req.params.id]);

    await db.execute(
      `INSERT INTO rls_audit_log (action, target_user, changed_by, detail)
       VALUES ('DELETE_USER', :u, 'system', 'User and all permissions removed')`,
      [user.rows[0].USERNAME]
    );

    res.json({ success: true, message: 'User deleted' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── PATCH toggle active status ────────────────────────
router.patch('/:id/toggle', async (req, res) => {
  try {
    await db.execute(
      `UPDATE rls_users SET is_active = CASE WHEN is_active=1 THEN 0 ELSE 1 END,
       updated_at = SYSDATE WHERE id = :id`,
      [req.params.id]
    );
    res.json({ success: true, message: 'Status toggled' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── GET audit log ─────────────────────────────────────
router.get('/audit/log', async (req, res) => {
  try {
    const result = await db.execute(`
      SELECT id, action, target_user, changed_by, detail,
             TO_CHAR(created_at,'YYYY-MM-DD HH24:MI:SS') AS created_at
      FROM rls_audit_log
      ORDER BY created_at DESC
      FETCH FIRST 200 ROWS ONLY
    `);
    res.json({ success: true, data: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
